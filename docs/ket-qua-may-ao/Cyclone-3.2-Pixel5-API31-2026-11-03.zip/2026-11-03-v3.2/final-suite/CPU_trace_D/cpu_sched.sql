SELECT p.pid,p.name AS process,t.name AS thread,ROUND(SUM(s.dur)/1e6,3) AS running_cpu_ms,COUNT(*) AS scheduling_slices
FROM sched s JOIN thread t ON s.utid=t.utid JOIN process p ON t.upid=p.upid
WHERE p.pid=12742 AND s.dur>0
GROUP BY p.pid,p.name,t.utid,t.name ORDER BY running_cpu_ms DESC;