Phiên 7 · ĐÃ DỪNG · 2007 ms
100 ảnh · http://127.0.0.1:8000 · JPEG · v1 · lỗi=true · trễ=0ms
Dừng: viewport_terminal

Cấu hình: D
Request tạo: 6, bắt đầu: 6, kết thúc: 6, chưa có kết quả: 0.
Thành công: 5 | Lỗi: 1 | Hủy: 0
NETWORK: n=5, median=206 / p90=237 ms
DISK: n=0, median=-1 / p90=-1 ms
MEMORY_CACHE: n=0, median=-1 / p90=-1 ms
MEMORY: n=0, median=-1 / p90=-1 ms
Decode: n=5, median=122 / p90=133 ms
Bitmap allocation mỗi kết quả: TB 0.96 MiB, lớn nhất 1.31 MiB (không phải RAM tiến trình).
Ví dụ bitmap: 478×637, HARDWARE.
-1 = không có số đo; memory hit thường không chạy decode. Thời gian request không phải thời gian hiển thị.
Percentile chỉ gồm request thành công kết thúc trong phiên; request chưa xong khi dừng không có thời gian hoàn tất.

Viewport đầu: 4 ảnh, sẵn sàng 4, lỗi 1.
Sẵn sàng vẽ viewport (pre-draw): 273 ms từ lúc phiên bắt đầu.
Đủ ảnh thành công trong viewport: chưa đạt.
Mốc gồm cả ảnh lỗi; không phải FullyDrawn hay thời điểm pixel xuất hiện trên màn hình.
PSS đỉnh lấy mẫu: 93.24 MiB, n=4, chu kỳ ≥500 ms.
CPU toàn tiến trình trong phiên: 599 ms (tổng các luồng, không phải CPU%).
ART GC: 0 lượt, tổng 0 ms; không phải thời gian Main Thread bị dừng.
PSS tính cả tiến trình; lấy mẫu có thể bỏ lỡ đỉnh giữa hai lần đo.
Frame trễ hạn hệ thống: 5/10 (API31+, TOTAL_DURATION >= DEADLINE).
Frame vượt 1 chu kỳ màn hình: 10/10 (100.00%).
TOTAL_DURATION > 1/refreshRate; loại first-draw. Đây không phải chỉ số jank chính thức của Android.
Frame p90: 129.66 ms.
Callback frame bị rơi: 0; frame vượt giới hạn lưu: 0.
Xuất sau khi dừng để tránh tác động I/O vào kết quả. Kết quả hiện tại chưa đại diện mọi thiết bị.

Percentile: nearest rank. Millisecond request values are rounded down. -1 means unavailable.
Request fetch time includes Coil fetcher work; NETWORK is Coil's source, not HTTP wire byte accounting.
RAM sample and frame metrics introduce measurement overhead. Do not sum repeated bitmap allocations as process memory.
