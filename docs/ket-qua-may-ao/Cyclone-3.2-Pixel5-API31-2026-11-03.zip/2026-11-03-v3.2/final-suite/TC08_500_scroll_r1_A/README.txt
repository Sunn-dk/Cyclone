Phiên 1 · ĐÃ DỪNG · 8184 ms
500 ảnh · http://127.0.0.1:8000 · JPEG · v1 · lỗi=false · trễ=0ms
Dừng: auto_scroll_end

Cấu hình: A
Request tạo: 25, bắt đầu: 25, kết thúc: 25, chưa có kết quả: 0.
Thành công: 23 | Lỗi: 0 | Hủy: 2
NETWORK: n=23, median=383 / p90=1101 ms
DISK: n=0, median=-1 / p90=-1 ms
MEMORY_CACHE: n=0, median=-1 / p90=-1 ms
MEMORY: n=0, median=-1 / p90=-1 ms
Decode: n=23, median=306 / p90=896 ms
Bitmap allocation mỗi kết quả: TB 26.62 MiB, lớn nhất 34.33 MiB (không phải RAM tiến trình).
Ví dụ bitmap: 2000×3000, HARDWARE.
-1 = không có số đo; memory hit thường không chạy decode. Thời gian request không phải thời gian hiển thị.
Percentile chỉ gồm request thành công kết thúc trong phiên; request chưa xong khi dừng không có thời gian hoàn tất.

Viewport đầu: 5 ảnh, sẵn sàng 2, lỗi 0.
Sẵn sàng vẽ viewport (pre-draw): chưa đạt từ lúc phiên bắt đầu.
Đủ ảnh thành công trong viewport: chưa đạt.
Mốc gồm cả ảnh lỗi; không phải FullyDrawn hay thời điểm pixel xuất hiện trên màn hình.
PSS đỉnh lấy mẫu: 155.31 MiB, n=15, chu kỳ ≥500 ms.
CPU toàn tiến trình trong phiên: 10257 ms (tổng các luồng, không phải CPU%).
ART GC: 11 lượt, tổng 535 ms; không phải thời gian Main Thread bị dừng.
PSS tính cả tiến trình; lấy mẫu có thể bỏ lỡ đỉnh giữa hai lần đo.
Frame trễ hạn hệ thống: 189/189 (API31+, TOTAL_DURATION >= DEADLINE).
Frame vượt 1 chu kỳ màn hình: 189/189 (100.00%).
TOTAL_DURATION > 1/refreshRate; loại first-draw. Đây không phải chỉ số jank chính thức của Android.
Frame p90: 234.44 ms.
Callback frame bị rơi: 0; frame vượt giới hạn lưu: 0.
Xuất sau khi dừng để tránh tác động I/O vào kết quả. Kết quả hiện tại chưa đại diện mọi thiết bị.

Percentile: nearest rank. Millisecond request values are rounded down. -1 means unavailable.
Request fetch time includes Coil fetcher work; NETWORK is Coil's source, not HTTP wire byte accounting.
RAM sample and frame metrics introduce measurement overhead. Do not sum repeated bitmap allocations as process memory.
